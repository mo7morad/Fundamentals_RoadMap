#include <iostream>
#include "headers/screens/clsMainScreen.h"

int main()
{
  clsMainScreen::ShowMainMenu();
  cin.get();
  return 0;
}