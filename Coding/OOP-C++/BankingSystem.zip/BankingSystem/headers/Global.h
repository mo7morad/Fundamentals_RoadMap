#pragma once
#include <iostream>
#include "core/clsUser.h"

clsUser CurrentUser=clsUser::Find("","");





