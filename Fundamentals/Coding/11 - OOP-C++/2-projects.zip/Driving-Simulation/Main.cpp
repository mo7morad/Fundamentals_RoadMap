#include <iostream>
#include "headers/screens/clsMainScreen.h"

int main()
{
  clsMainScreen::ShowMainMenu();
  return 0;
}