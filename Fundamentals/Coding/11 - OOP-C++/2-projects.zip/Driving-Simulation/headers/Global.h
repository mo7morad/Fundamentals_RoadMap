#pragma once
#include <iostream>
#include "core/Car.h"

static Car CurrentCar;
static string CurrentTrack;
static float TrackLength;
