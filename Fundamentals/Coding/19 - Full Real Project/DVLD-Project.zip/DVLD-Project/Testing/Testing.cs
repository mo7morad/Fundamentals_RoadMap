﻿using BusinessLayer;
using System;
using System.Data;
using Entities;

namespace ConsoleTesting
{
    internal class Testing
    {
        static void Main(string[] args)
        {
            
        }
    }
}
