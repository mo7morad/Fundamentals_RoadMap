﻿namespace DVLD
{
    public static class clsCurrentSession
    {
        public static string LoggedInUserName { get; set; }
        public static int LoggedInUserID { get; set; }
    }
}
