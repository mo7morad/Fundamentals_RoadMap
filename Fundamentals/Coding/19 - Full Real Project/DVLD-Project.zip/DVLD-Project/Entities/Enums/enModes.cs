﻿namespace Entities.Enums
{
    public enum enFormMode
    {
        AddNew,
        Update
    }
}
