﻿namespace DVLD_Entities.Enums
{
    public enum enFormMode
    {
        AddNew,
        Update
    }
}
