﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Enums
{
    public enum enAppStatus
    {
        Pending = 1,
        Rejected = 2,
        Approved = 3
    }
}
